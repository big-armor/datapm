export enum Permissions {
  Manage = "MANAGE",
  Create = "CREATE",
  View = "VIEW",
  Edit = "EDIT",
  Delete  = "DELETE",
  None  = "NONE"
}